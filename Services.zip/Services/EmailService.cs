﻿using KCHitterDAD.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Threading.Tasks;
using System.Web;

namespace KCHitterDAD.Views.Services
{
    public class EmailService
    
        {
            //Asynchronous method to send emaill based on ContactForm object
            public async static Task SendContactForm(ContactForm contactForm)
            {
                //Constructing the email
                string body = "<p>The following is a message from {0} ({1})</p><p>{2}</p>";
                MailMessage message = new MailMessage();
                message.To.Add(new MailAddress("destination@domain.com"));
                message.Subject = "Contact Form Message";
                message.Body = string.Format(body, contactForm.Name, contactForm.Email, contactForm.Message);
                message.IsBodyHtml = true;

                //Attempting to send the email
                using (SmtpClient smtpClient = new SmtpClient())
                {
                    await smtpClient.SendMailAsync(message);
                }
            }
        }
    }